T.MONEY - ANDROID WEBVIEW PROJECT (LATEST APPROVED WEB BUILD)

Đây là mã nguồn dự án Android bọc bản web T.money bằng WebView.
Chưa phải file APK đã biên dịch.

CÁCH TẠO APK:
1. Cài Android Studio trên máy tính.
2. Giải nén T_money_Android_Project.zip.
3. Android Studio > Open > chọn thư mục T_money_Android_Project.
4. Chờ Gradle Sync hoàn tất và cài Android SDK Platform 35 nếu được yêu cầu.
5. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug thường nằm tại:
   app/build/outputs/apk/debug/app-debug.apk

THÔNG TIN:
- Tên ứng dụng: T.money
- Application ID: com.tmoney.app
- Mã web: app/src/main/assets/index.html
- Logo: app/src/main/res/drawable-nodpi/tmoney_logo.png

LƯU Ý:
- Môi trường tạo file hiện tại không có Android SDK/Gradle nên chưa thể biên dịch APK trực tiếp.
- Hãy thử cài bản debug và kiểm tra toàn bộ chức năng trên điện thoại trước khi phát hành.
- Dữ liệu WebView được lưu trong vùng dữ liệu riêng của ứng dụng; gỡ ứng dụng có thể làm mất dữ liệu cục bộ. Hãy sao lưu trước.


BAN WEB DUNG DE DONG GOI APK: T_money_moi_nhat_web_xem_truoc.html
