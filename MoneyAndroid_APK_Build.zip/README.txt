MONEY ANDROID - APK BUILD PACKAGE
=================================

This package contains the Money app with:
- Personal finance: income, expenses, reports, loans.
- Group bill splitting: create groups, record repayments, add/remove participants.
- Attendance and overtime calendar embedded in the Money app.
- Money logo used in the Android launcher icon.
- Local data storage and backup/restore.

IMPORTANT FIX:
The attendance calendar document was previously initialized inside the
"year report" function, so the attendance iframe could remain blank when
opening the app. It is now initialized once when the app loads. The
"year report" function only changes the report period.

BUILD APK USING GITHUB ACTIONS ON YOUR PHONE
1. Sign in to https://github.com.
2. Create a repository named MoneyAndroid.
3. Upload the CONTENTS of this extracted project folder (keep folder paths).
   Do not upload the ZIP as a single file.
4. Commit the files to the main branch.
5. Open the repository's Actions tab.
6. Select "Build Money APK" and tap "Run workflow".
7. Wait until the run shows a green check / Succeeded.
8. Open that run, go to Artifacts, and download "Money-APK".
9. Extract the downloaded artifact ZIP and install app-debug.apk.

The workflow creates a debug APK for testing. Android may ask you to allow
installation from the browser or file manager.

PROJECT CONTENTS
- app/src/main/assets/index.html: complete Money app.
- app/src/main/res/drawable-nodpi/money_app_icon.png: app icon.
- app/src/main/AndroidManifest.xml and MainActivity.java: Android wrapper.
- .github/workflows/build-apk.yml: GitHub Actions APK workflow.
